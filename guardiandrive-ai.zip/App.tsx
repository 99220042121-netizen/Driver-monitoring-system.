import React, { useState, useEffect } from 'react';
import { Auth } from './components/Auth';
import { ProfileSetup } from './components/ProfileSetup';
import { DriveMonitor } from './components/DriveMonitor';
import { User, AppState } from './types';

function App() {
  const [appState, setAppState] = useState<AppState>(AppState.AUTH);
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  // Check if we have a persisted session (simple mock)
  useEffect(() => {
    const savedUser = localStorage.getItem('gd_current_user');
    if (savedUser) {
      const user = JSON.parse(savedUser);
      setCurrentUser(user);
      if (user.carRegistration && user.emergencyContacts.length > 0) {
        setAppState(AppState.DASHBOARD);
      } else {
        setAppState(AppState.PROFILE_SETUP);
      }
    }
  }, []);

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('gd_current_user', JSON.stringify(user));
    if (user.carRegistration && user.emergencyContacts.length > 0) {
      setAppState(AppState.DASHBOARD);
    } else {
      setAppState(AppState.PROFILE_SETUP);
    }
  };

  const handleProfileComplete = (updatedUser: User) => {
    setCurrentUser(updatedUser);
    localStorage.setItem('gd_current_user', JSON.stringify(updatedUser));
    setAppState(AppState.DASHBOARD);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('gd_current_user');
    setAppState(AppState.AUTH);
  };

  return (
    <div className="font-sans antialiased text-white">
      {appState === AppState.AUTH && (
        <Auth onLogin={handleLogin} />
      )}
      
      {appState === AppState.PROFILE_SETUP && currentUser && (
        <ProfileSetup currentUser={currentUser} onComplete={handleProfileComplete} />
      )}
      
      {appState === AppState.DASHBOARD && currentUser && (
        <DriveMonitor user={currentUser} onLogout={handleLogout} />
      )}
    </div>
  );
}

export default App;