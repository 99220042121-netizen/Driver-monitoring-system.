import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Button } from './Button';
import { User, DriverStatus, AccidentReport } from '../types';
import { analyzeDriverState, monitorDriver, DriverAnalysis } from '../services/geminiService';

interface DriveMonitorProps {
  user: User;
  onLogout: () => void;
}

export const DriveMonitor: React.FC<DriveMonitorProps> = ({ user, onLogout }) => {
  const [engineStarted, setEngineStarted] = useState(false);
  const [status, setStatus] = useState<DriverStatus>(DriverStatus.SAFE);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [report, setReport] = useState<AccidentReport | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [boundingBox, setBoundingBox] = useState<[number, number, number, number] | null>(null);
  const [lastReason, setLastReason] = useState<string>("");

  // Refs for media and logic
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const oscillatorRef = useRef<OscillatorNode | null>(null);
  const monitoringRef = useRef<boolean>(false); // Track if loop should run

  // Audio beep function (Alarm)
  const startBeep = useCallback(() => {
    if (!audioContextRef.current) {
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    const ctx = audioContextRef.current;
    
    // Create oscillator
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    
    osc.type = 'square';
    osc.frequency.setValueAtTime(800, ctx.currentTime); // Alert frequency
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    // Pulse effect
    const now = ctx.currentTime;
    gain.gain.setValueAtTime(0.5, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.5);
    
    osc.start(now);
    osc.stop(now + 0.5);
    
    oscillatorRef.current = osc;
  }, []);

  const playEngineSound = () => {
    if (!audioContextRef.current) {
        audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    const ctx = audioContextRef.current;
    
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gain = ctx.createGain();
    
    // Simulate engine rumble with low frequency sawtooth and square waves
    const now = ctx.currentTime;

    // Oscillator 1: Main engine tone (Sawtooth for grit)
    osc1.type = 'sawtooth';
    osc1.frequency.setValueAtTime(50, now); // Low start
    osc1.frequency.linearRampToValueAtTime(150, now + 0.4); // Rev up
    osc1.frequency.exponentialRampToValueAtTime(60, now + 2.0); // Idle down

    // Oscillator 2: Sub-bass rumble (Square for body)
    osc2.type = 'square';
    osc2.frequency.setValueAtTime(25, now);
    osc2.frequency.linearRampToValueAtTime(75, now + 0.4);
    osc2.frequency.exponentialRampToValueAtTime(30, now + 2.0);
    
    // Volume envelope
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.5, now + 0.1);
    gain.gain.linearRampToValueAtTime(0.3, now + 1.5);
    gain.gain.linearRampToValueAtTime(0, now + 3.0);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 3);
    osc2.stop(now + 3);
  };

  // Start Camera
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 } });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Camera error:", err);
      alert("Camera permission denied. The system cannot monitor you.");
    }
  };

  const handleStartEngine = () => {
    playEngineSound();
    setEngineStarted(true);
    startCamera();
  };

  // Capture Image
  const captureImage = useCallback((): string | null => {
    if (videoRef.current && canvasRef.current) {
      const vid = videoRef.current;
      const can = canvasRef.current;
      // Match canvas size to video size
      can.width = vid.videoWidth || 640;
      can.height = vid.videoHeight || 480;
      const ctx = can.getContext('2d');
      if (ctx) {
        ctx.drawImage(vid, 0, 0, can.width, can.height);
        return can.toDataURL('image/jpeg', 0.8);
      }
    }
    return null;
  }, []);

  // Monitoring Loop
  useEffect(() => {
    let timeoutId: ReturnType<typeof setTimeout>;

    const runMonitoring = async () => {
      // Only monitor if engine started, no countdown active, no report, and system isn't currently handling an alert
      if (!engineStarted || countdown !== null || report || !monitoringRef.current) return;

      const image = captureImage();
      if (image) {
        // We don't set global 'isAnalyzing' here to avoid flickering UI, 
        // this is background monitoring
        try {
          const result: DriverAnalysis = await monitorDriver(image);
          
          if (result.box_2d) {
            setBoundingBox(result.box_2d);
          } else {
            setBoundingBox(null);
          }

          setLastReason(result.reason || "");

          if (result.status !== 'SAFE') {
            // DANGER DETECTED
            setStatus(result.status as DriverStatus);
            setCountdown(10); // Start countdown immediately
            monitoringRef.current = false; // Stop monitoring loop
          } else {
            setStatus(DriverStatus.SAFE);
          }
        } catch (e) {
          console.error("Monitoring loop error", e);
        }
      }

      // Schedule next check in 2 seconds (debounce)
      if (monitoringRef.current) {
        timeoutId = setTimeout(runMonitoring, 2000);
      }
    };

    if (engineStarted && countdown === null && !report) {
      monitoringRef.current = true;
      runMonitoring();
    } else {
      monitoringRef.current = false;
    }

    return () => {
      monitoringRef.current = false;
      clearTimeout(timeoutId);
    };
  }, [engineStarted, countdown, report, captureImage]);


  // Mark Safe
  const handleMarkSafe = () => {
    setStatus(DriverStatus.SAFE);
    setCountdown(null);
    setLastReason("User confirmed safety.");
    // This will naturally re-trigger the useEffect to start monitoring again
  };

  const handleReset = () => {
    setReport(null);
    setCountdown(null);
    setStatus(DriverStatus.SAFE);
    setEngineStarted(false);
    setIsAnalyzing(false);
    setBoundingBox(null);
    setLastReason("");
    monitoringRef.current = false;
  };

  // Countdown Effect
  useEffect(() => {
    let interval: ReturnType<typeof setInterval>;
    if (countdown !== null && countdown > 0) {
      interval = setInterval(() => {
        setCountdown((prev) => (prev !== null ? prev - 1 : null));
        startBeep(); // Beep every second
      }, 1000);
    } else if (countdown === 0) {
      // Emergency Trigger!
      const lastPic = captureImage();
      setCountdown(null);
      setIsAnalyzing(true);
      
      // Call detailed Gemini analysis for report
      if (lastPic) {
        analyzeDriverState(lastPic).then(analysis => {
          setReport({
            timestamp: new Date().toLocaleString(),
            location: "Lat: 40.7128, Long: -74.0060 (Simulated)",
            status: status,
            imageUrl: lastPic,
            aiAnalysis: analysis
          });
          setIsAnalyzing(false);
        });
      } else {
        setReport({
            timestamp: new Date().toLocaleString(),
            location: "Lat: 40.7128, Long: -74.0060 (Simulated)",
            status: status,
            aiAnalysis: "Camera feed unavailable."
        });
        setIsAnalyzing(false);
      }
    }
    return () => clearInterval(interval);
  }, [countdown, startBeep, status, captureImage]);

  // Render Dashboard
  if (!engineStarted) {
    return (
      <div className="min-h-screen bg-dashboard-bg flex flex-col items-center justify-center relative">
        <div className="absolute top-4 right-4">
            <button onClick={onLogout} className="text-gray-400 hover:text-white">Logout</button>
        </div>
        <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-white mb-2">Welcome, {user.fullName?.split(' ')[0]}</h1>
            <p className="text-gray-400">System Ready. Press Start to initialize monitoring.</p>
        </div>
        <button 
          onClick={handleStartEngine}
          className="w-48 h-48 rounded-full border-4 border-blue-500 bg-gray-800 shadow-[0_0_50px_rgba(59,130,246,0.3)] hover:shadow-[0_0_80px_rgba(59,130,246,0.5)] flex flex-col items-center justify-center transition-all group"
        >
          <span className="text-gray-400 text-sm font-semibold tracking-widest mb-2 group-hover:text-white">ENGINE</span>
          <span className="text-blue-400 text-3xl font-bold group-hover:text-blue-300">START</span>
        </button>
      </div>
    );
  }

  // Emergency Report View
  if (report) {
    return (
      <div className="min-h-screen bg-red-950/30 flex items-center justify-center p-4">
        <div className="max-w-4xl w-full bg-dashboard-panel border border-red-600 rounded-2xl overflow-hidden shadow-2xl relative">
          <div className="bg-red-600 p-4 animate-pulse flex justify-between items-center">
            <h1 className="text-white text-2xl font-bold uppercase tracking-widest">Emergency Alert Triggered</h1>
            <span className="text-white font-mono text-sm">{report.timestamp}</span>
          </div>
          
          <div className="p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
                {/* Driver Details Section */}
               <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700">
                 <h3 className="text-gray-400 text-sm uppercase mb-3 border-b border-gray-700 pb-2">Driver Information</h3>
                 <div className="flex items-start gap-4">
                    {user.photoUrl ? (
                        <img src={user.photoUrl} alt="Driver" className="w-24 h-32 object-cover rounded-lg border border-gray-600 bg-gray-900 shadow-md" />
                    ) : (
                        <div className="w-24 h-32 bg-gray-700 rounded-lg flex items-center justify-center text-gray-500 text-xs border border-gray-600">No Photo</div>
                    )}
                    <div className="space-y-2 flex-1">
                        <div>
                            <p className="text-gray-500 text-[10px] uppercase tracking-wider">Name</p>
                            <p className="text-white font-bold text-lg leading-tight">{user.fullName || 'Unknown'}</p>
                        </div>
                        <div>
                            <p className="text-gray-500 text-[10px] uppercase tracking-wider">Vehicle No.</p>
                            <div className="inline-block bg-yellow-400/10 border border-yellow-400/30 px-2 py-0.5 rounded">
                                <p className="text-yellow-400 font-mono text-base tracking-widest">{user.carRegistration || 'Unknown'}</p>
                            </div>
                        </div>
                         <div>
                            <p className="text-gray-500 text-[10px] uppercase tracking-wider">Mobile</p>
                            <p className="text-gray-300 font-mono text-sm">{user.mobileNumber || 'Unknown'}</p>
                        </div>
                    </div>
                 </div>
               </div>

               <div>
                 <h3 className="text-gray-400 text-sm uppercase mb-2">Last Camera Capture</h3>
                 {report.imageUrl ? (
                   <div className="relative rounded-xl overflow-hidden border-2 border-red-500 shadow-lg">
                     <img src={report.imageUrl} alt="Last frame" className="w-full h-48 object-cover" />
                     <div className="absolute bottom-0 left-0 right-0 bg-black/70 p-2">
                       <p className="text-red-400 font-bold text-center">{report.status}</p>
                     </div>
                   </div>
                 ) : (
                   <div className="w-full h-48 bg-gray-800 rounded-xl flex items-center justify-center">
                      <p className="text-gray-500">No Image Captured</p>
                   </div>
                 )}
              </div>
            </div>

            <div className="space-y-6">
               <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700">
                 <h3 className="text-gray-400 text-sm uppercase mb-2">Automated Actions</h3>
                 <ul className="space-y-3">
                    {user.emergencyContacts.map((contact, idx) => (
                        <li key={idx} className="flex items-center text-green-400">
                             <span className="mr-2">✓</span>
                             Calling {contact.name} ({contact.number})...
                        </li>
                    ))}
                    <li className="flex items-center text-green-400">
                         <span className="mr-2">✓</span>
                         Ambulance Dispatch Notified
                    </li>
                 </ul>
               </div>

               <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700">
                 <h3 className="text-gray-400 text-sm uppercase mb-2">AI Assessment</h3>
                 <p className="text-white italic text-sm leading-relaxed">
                    "{report.aiAnalysis}"
                 </p>
               </div>

               <Button variant="outline" onClick={handleReset} fullWidth>
                 Reset System
               </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Calculate box style from Gemini coordinates (0-1000 scale)
  const getBoxStyle = () => {
    if (!boundingBox) return { top: '50%', left: '50%', width: '50%', height: '50%', transform: 'translate(-50%, -50%)' };
    
    // box_2d is [ymin, xmin, ymax, xmax]
    const [ymin, xmin, ymax, xmax] = boundingBox;
    return {
        top: `${ymin / 10}%`,
        left: `${xmin / 10}%`,
        height: `${(ymax - ymin) / 10}%`,
        width: `${(xmax - xmin) / 10}%`,
    };
  };

  // Monitoring View
  return (
    <div className="h-screen bg-dashboard-bg flex flex-col p-4 overflow-hidden">
      {/* Header - Fixed Height */}
      <div className="flex justify-between items-center mb-4 bg-dashboard-panel p-3 rounded-xl border border-gray-700 flex-shrink-0">
         <div className="flex items-center gap-4">
            <div className={`w-3 h-3 rounded-full ${status === DriverStatus.SAFE ? 'bg-green-500 animate-pulse' : 'bg-red-500 animate-pulse-fast'}`}></div>
            <div>
                <span className={`font-mono font-bold tracking-wider text-sm md:text-base ${status === DriverStatus.SAFE ? 'text-white' : 'text-red-500'}`}>
                    {status === DriverStatus.SAFE ? 'SYSTEM ACTIVE // MONITORING' : `WARNING: ${status} DETECTED`}
                </span>
                {lastReason && <p className="text-[10px] md:text-xs text-gray-400 mt-0.5">{lastReason}</p>}
            </div>
         </div>
         <div className="text-right">
             <p className="text-gray-400 text-[10px]">VEHICLE ID</p>
             <p className="text-white font-mono text-sm">{user.carRegistration}</p>
         </div>
      </div>

      <div className="flex-1 flex gap-6 min-h-0">
        {/* Main Feed Container - Flexible but constrained */}
        <div className="flex-1 relative bg-black rounded-2xl overflow-hidden border-2 border-gray-800 shadow-2xl flex flex-col w-full h-full">
            <video 
                ref={videoRef} 
                autoPlay 
                playsInline 
                muted 
                className={`w-full h-full object-cover ${status !== DriverStatus.SAFE ? 'grayscale contrast-125' : ''}`}
            />
            <canvas ref={canvasRef} className="hidden" />
            
            {/* Overlay Interface */}
            <div className="absolute inset-0 pointer-events-none">
                {/* Dynamic AI Face/Body Box */}
                {boundingBox && (
                    <div 
                        className={`absolute border-4 transition-all duration-300 ease-out rounded-lg
                        ${status === DriverStatus.SAFE ? 'border-green-500/80 shadow-[0_0_20px_rgba(34,197,94,0.3)]' : 'border-red-500 shadow-[0_0_30px_rgba(239,68,68,0.5)] animate-pulse'}`}
                        style={getBoxStyle()}
                    >
                        <div className={`absolute -top-8 left-0 px-3 py-1 text-sm font-bold rounded-t-lg
                            ${status === DriverStatus.SAFE ? 'bg-green-500 text-black' : 'bg-red-500 text-white'}`}
                        >
                             {status === DriverStatus.SAFE ? 'SAFE' : status}
                        </div>
                    </div>
                )}

                {/* Status if no box (e.g. MISSING) */}
                {status === DriverStatus.MISSING && !boundingBox && (
                    <div className="absolute inset-0 flex items-center justify-center">
                        <div className="bg-red-500/80 p-6 rounded-xl animate-pulse">
                            <h2 className="text-4xl font-black text-white">DRIVER MISSING</h2>
                        </div>
                    </div>
                )}

                {/* HUD Elements */}
                <div className="absolute bottom-4 left-4 font-mono text-xs text-green-500/70">
                    <p>CAM_01: ACTIVE</p>
                    <p>AI_MODEL: GEMINI-2.5-FLASH</p>
                    <p>LATENCY: ~200ms</p>
                </div>
            </div>

            {/* Warning Overlay */}
            {countdown !== null && (
                <div className="absolute inset-0 bg-red-500/20 z-10 flex flex-col items-center justify-center animate-pulse">
                    <h2 className="text-6xl font-black text-white mb-8 drop-shadow-md">{countdown}s</h2>
                    <p className="text-xl text-white font-bold mb-8 uppercase tracking-widest">Verify Safety</p>
                    <button 
                        onClick={handleMarkSafe}
                        className="pointer-events-auto bg-green-600 hover:bg-green-500 text-white w-32 h-32 rounded-full font-bold text-xl shadow-[0_0_50px_rgba(34,197,94,0.6)] transform hover:scale-105 transition-all border-4 border-white"
                    >
                        I AM SAFE
                    </button>
                </div>
            )}
            
            {isAnalyzing && (
                 <div className="absolute inset-0 bg-black/80 z-20 flex flex-col items-center justify-center">
                    <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mb-4"></div>
                    <p className="text-blue-400 font-mono animate-pulse">FINALIZING EMERGENCY REPORT...</p>
                 </div>
            )}
        </div>
      </div>
    </div>
  );
};