import React, { useState } from 'react';
import { Button } from './Button';
import { User, EmergencyContact } from '../types';

interface ProfileSetupProps {
  currentUser: User;
  onComplete: (updatedUser: User) => void;
}

export const ProfileSetup: React.FC<ProfileSetupProps> = ({ currentUser, onComplete }) => {
  const [fullName, setFullName] = useState(currentUser.fullName || '');
  const [carReg, setCarReg] = useState(currentUser.carRegistration || '');
  const [mobile, setMobile] = useState(currentUser.mobileNumber || '');
  const [contacts, setContacts] = useState<EmergencyContact[]>(currentUser.emergencyContacts || []);
  const [photo, setPhoto] = useState<string | null>(currentUser.photoUrl || null);
  
  // New Contact State
  const [newContactName, setNewContactName] = useState('');
  const [newContactNumber, setNewContactNumber] = useState('');

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhoto(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const addContact = () => {
    if (newContactName && newContactNumber) {
      setContacts([...contacts, {
        id: Date.now().toString(),
        name: newContactName,
        number: newContactNumber
      }]);
      setNewContactName('');
      setNewContactNumber('');
    }
  };

  const removeContact = (id: string) => {
    setContacts(contacts.filter(c => c.id !== id));
  };

  const handleSave = () => {
    if (!fullName || !carReg || !mobile || contacts.length === 0) {
      alert('Please fill in all required fields and add at least one emergency contact.');
      return;
    }

    const updatedUser: User = {
      ...currentUser,
      fullName,
      carRegistration: carReg,
      mobileNumber: mobile,
      emergencyContacts: contacts,
      photoUrl: photo || undefined
    };

    // Update local storage
    const storedUsersStr = localStorage.getItem('gd_users');
    if (storedUsersStr) {
      const storedUsers = JSON.parse(storedUsersStr);
      storedUsers[currentUser.username] = updatedUser;
      localStorage.setItem('gd_users', JSON.stringify(storedUsers));
    }

    onComplete(updatedUser);
  };

  return (
    <div className="min-h-screen bg-dashboard-bg p-6 flex flex-col items-center">
      <div className="w-full max-w-3xl bg-dashboard-panel border border-gray-700 rounded-2xl p-8 shadow-xl">
        <h2 className="text-2xl font-bold text-white mb-6 border-b border-gray-700 pb-4">Vehicle & Driver Setup</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Left Column: Personal Info */}
          <div className="space-y-6">
            <div className="flex flex-col items-center justify-center p-4 border-2 border-dashed border-gray-600 rounded-xl hover:border-blue-500 transition-colors cursor-pointer relative group">
              <input type="file" accept="image/*" onChange={handlePhotoUpload} className="absolute inset-0 opacity-0 cursor-pointer z-10" />
              {photo ? (
                <img src={photo} alt="Profile" className="w-32 h-32 rounded-full object-cover border-4 border-blue-500" />
              ) : (
                <div className="w-32 h-32 rounded-full bg-gray-700 flex items-center justify-center text-gray-400">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                </div>
              )}
              <p className="text-sm text-gray-400 mt-2 group-hover:text-blue-400">Upload Driver Photo</p>
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-1">Full Name</label>
              <input type="text" value={fullName} onChange={e => setFullName(e.target.value)} className="w-full bg-gray-800 rounded-lg px-4 py-2 text-white border border-gray-600 focus:border-blue-500 outline-none" placeholder="John Doe" />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-1">Car Registration Number</label>
              <input type="text" value={carReg} onChange={e => setCarReg(e.target.value)} className="w-full bg-gray-800 rounded-lg px-4 py-2 text-white border border-gray-600 focus:border-blue-500 outline-none" placeholder="ABC-1234" />
            </div>
            <div>
              <label className="block text-sm text-gray-400 mb-1">Your Mobile Number</label>
              <input type="tel" value={mobile} onChange={e => setMobile(e.target.value)} className="w-full bg-gray-800 rounded-lg px-4 py-2 text-white border border-gray-600 focus:border-blue-500 outline-none" placeholder="+1 234 567 890" />
            </div>
          </div>

          {/* Right Column: Emergency Contacts */}
          <div className="space-y-6">
            <h3 className="text-lg font-semibold text-white">Emergency Contacts</h3>
            <div className="bg-gray-800/50 p-4 rounded-xl border border-gray-700 space-y-4">
              <div className="space-y-3">
                <input 
                  type="text" 
                  value={newContactName} 
                  onChange={e => setNewContactName(e.target.value)} 
                  className="w-full bg-gray-900 rounded-lg px-3 py-2 text-sm text-white border border-gray-600 focus:border-blue-500 outline-none" 
                  placeholder="Contact Name (e.g. Mom)" 
                />
                <div className="flex gap-2">
                  <input 
                    type="tel" 
                    value={newContactNumber} 
                    onChange={e => setNewContactNumber(e.target.value)} 
                    className="w-full bg-gray-900 rounded-lg px-3 py-2 text-sm text-white border border-gray-600 focus:border-blue-500 outline-none" 
                    placeholder="Number" 
                  />
                  <button onClick={addContact} className="bg-blue-600 hover:bg-blue-500 text-white px-4 rounded-lg text-sm font-semibold transition-colors">Add</button>
                </div>
              </div>

              <div className="max-h-48 overflow-y-auto space-y-2 mt-4 custom-scrollbar">
                {contacts.length === 0 && <p className="text-gray-500 text-sm italic">No contacts added yet.</p>}
                {contacts.map(contact => (
                  <div key={contact.id} className="flex items-center justify-between bg-gray-700 p-2 rounded-lg">
                    <div>
                      <p className="text-white text-sm font-medium">{contact.name}</p>
                      <p className="text-gray-400 text-xs">{contact.number}</p>
                    </div>
                    <button onClick={() => removeContact(contact.id)} className="text-red-400 hover:text-red-300 p-1">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-gray-700 flex justify-end">
          <Button onClick={handleSave} className="w-full md:w-auto min-w-[200px]">Complete Setup &rarr;</Button>
        </div>
      </div>
    </div>
  );
};