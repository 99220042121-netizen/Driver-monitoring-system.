import { GoogleGenAI, Type } from "@google/genai";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    console.error("API_KEY is missing");
    throw new Error("API Key is required");
  }
  return new GoogleGenAI({ apiKey });
};

export interface DriverAnalysis {
  status: 'SAFE' | 'UNCONSCIOUS' | 'MISSING';
  reason: string;
  box_2d?: [number, number, number, number]; // [ymin, xmin, ymax, xmax] 0-1000 scale
}

export const monitorDriver = async (imageBase64: string): Promise<DriverAnalysis> => {
  try {
    const ai = getClient();
    const cleanBase64 = imageBase64.split(',')[1] || imageBase64;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: cleanBase64
            }
          },
          {
            text: `Analyze the driver in this image for a safety monitoring system. 
            - If no one is in the driver's seat, return status "MISSING".
            - If the driver's eyes are closed, head is slumped, or they appear asleep/unconscious, return status "UNCONSCIOUS".
            - Otherwise, return status "SAFE".
            Provide a bounding box [ymin, xmin, ymax, xmax] (0-1000 scale) around the driver's face or upper body.`
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            status: {
              type: Type.STRING,
              enum: ["SAFE", "UNCONSCIOUS", "MISSING"]
            },
            reason: {
              type: Type.STRING
            },
            box_2d: {
              type: Type.ARRAY,
              items: { type: Type.INTEGER }
            }
          }
        }
      }
    });

    if (response.text) {
        return JSON.parse(response.text) as DriverAnalysis;
    }
    throw new Error("No response text");
  } catch (error) {
    console.error("Monitoring Error:", error);
    // Default to safe on error to prevent false alarms during network blips
    return { status: "SAFE", reason: "Network error", box_2d: [200, 200, 800, 800] }; 
  }
};

// Kept for the final report generation which might need more descriptive text
export const analyzeDriverState = async (imageBase64: string): Promise<string> => {
  try {
    const ai = getClient();
    const cleanBase64 = imageBase64.split(',')[1] || imageBase64;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: "image/jpeg",
              data: cleanBase64
            }
          },
          {
            text: "You are an emergency response AI. Analyze this image of a driver immediately. Is the driver visible? Are their eyes closed or open? Do they look unconscious or in distress? Provide a very short, urgent status report for emergency services (max 2 sentences)."
          }
        ]
      }
    });

    return response.text || "Analysis failed. Emergency services alerted immediately.";
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return "Could not analyze image due to network error. Emergency services alerted.";
  }
};