export enum AppState {
  AUTH = 'AUTH',
  PROFILE_SETUP = 'PROFILE_SETUP',
  DASHBOARD = 'DASHBOARD',
}

export interface User {
  username: string;
  password?: string; // stored for mock auth
  fullName?: string;
  carRegistration?: string;
  mobileNumber?: string;
  emergencyContacts: EmergencyContact[];
  photoUrl?: string;
}

export interface EmergencyContact {
  id: string;
  name: string;
  number: string;
}

export enum DriverStatus {
  SAFE = 'SAFE',
  UNCONSCIOUS = 'UNCONSCIOUS',
  MISSING = 'MISSING',
}

export interface AccidentReport {
  timestamp: string;
  location: string; // Mocked
  status: DriverStatus;
  aiAnalysis?: string;
  imageUrl?: string;
}